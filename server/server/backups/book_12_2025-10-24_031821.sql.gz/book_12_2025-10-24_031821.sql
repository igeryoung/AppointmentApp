-- Schedule Note Book Backup
-- Generated: 2025-10-24T03:18:21.550373Z
-- Format: PostgreSQL SQL

-- Book
DELETE FROM books WHERE id = 12;
INSERT INTO books (id, device_id, book_uuid, name, created_at, updated_at, archived_at, synced_at, version, is_deleted) VALUES (12, 'f395c0e9-6e14-481e-ac74-bdbe0ef3ec06', 'db15de08-d8e7-4e6f-976c-e26564f18541', 'Quick Test Book', '2025-10-24T11:17:49.610867Z', '2025-10-24T11:17:49.610867Z', NULL, '2025-10-24T11:17:49.610867Z', 1, false);

-- End of backup
